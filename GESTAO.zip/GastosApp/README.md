# Controle de Gastos Residenciais

Sistema de controle de gastos residenciais, conforme especificação:
cadastro de pessoas, cadastro de transações (receitas/despesas) e consulta
de totais por pessoa + total geral.

- **Back-end**: .NET 8 / C#, com Entity Framework Core + SQLite (persistência
  em arquivo `gastos.db`, sobrevive a reinicializações da aplicação).
- **Front-end**: React + TypeScript (Vite).

## Regras de negócio implementadas

- Identificadores de pessoa e de transação são gerados automaticamente
  (auto-incremento no banco).
- Ao excluir uma pessoa, todas as suas transações são excluídas junto
  (cascade delete configurado no `AppDbContext`).
- Toda transação precisa referenciar uma pessoa existente no cadastro
  (validado em `TransactionsController`).
- Pessoas menores de 18 anos só podem ter **despesas** cadastradas, nunca
  receitas (validado no back-end em `TransactionsController` e refletido na
  interface, que desabilita a opção "Receita" nesse caso).
- Consulta de totais lista receita, despesa e saldo (receita − despesa) por
  pessoa, e o total geral somando todas as pessoas.

## Estrutura

```
GastosApp/
  backend/            -> API .NET (GastosApi.sln)
    GastosApi/
      Models/          -> entidades (Person, Transaction, TransactionType)
      Data/            -> AppDbContext (EF Core + SQLite)
      DTOs/            -> objetos de entrada/saída da API
      Controllers/     -> PeopleController, TransactionsController, TotalsController
  frontend/           -> aplicação React + TypeScript (Vite)
    src/
      components/      -> PersonForm, PeopleList, TransactionForm, TotalsView
      api.ts           -> chamadas HTTP para a API
      types.ts         -> tipos espelhando os DTOs do back-end
```

## Como rodar

### 1. Back-end (.NET)

Pré-requisito: [.NET 8 SDK](https://dotnet.microsoft.com/download).

```bash
cd backend/GastosApi
dotnet restore
dotnet ef database update    # opcional: EnsureCreated já cria o banco ao rodar
dotnet run
```

A API sobe em `http://localhost:5236` (ver `Properties/launchSettings.json`)
e o Swagger fica disponível em `http://localhost:5236/swagger`.

O arquivo `gastos.db` (SQLite) é criado automaticamente na primeira
execução, na mesma pasta do projeto, garantindo que os dados persistam
entre execuções.

### 2. Front-end (React)

Pré-requisito: Node.js 18+.

```bash
cd frontend
npm install
npm run dev
```

A aplicação sobe em `http://localhost:5173` e consome a API em
`http://localhost:5236` (ver `src/api.ts` — ajuste `API_BASE` caso a porta
do back-end seja diferente).

## Endpoints da API

| Método | Rota                  | Descrição                                   |
|--------|-----------------------|----------------------------------------------|
| GET    | /api/people           | Lista pessoas                                |
| POST   | /api/people           | Cria pessoa (`{ name, age }`)                 |
| DELETE | /api/people/{id}      | Exclui pessoa (e suas transações)             |
| GET    | /api/transactions     | Lista transações                              |
| POST   | /api/transactions     | Cria transação (`{ description, value, type, personId }`) |
| GET    | /api/totals           | Totais por pessoa + total geral               |
