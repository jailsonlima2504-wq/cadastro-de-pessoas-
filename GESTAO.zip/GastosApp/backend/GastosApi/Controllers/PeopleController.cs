using GastosApi.Data;
using GastosApi.DTOs;
using GastosApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GastosApi.Controllers;

/// <summary>
/// Endpoints do cadastro de pessoas: criação, listagem e deleção
/// (a especificação não pede edição de pessoa).
/// </summary>
[ApiController]
[Route("api/people")]
public class PeopleController : ControllerBase
{
    private readonly AppDbContext _db;

    public PeopleController(AppDbContext db)
    {
        _db = db;
    }

    /// <summary>GET /api/people — lista todas as pessoas cadastradas.</summary>
    [HttpGet]
    public async Task<ActionResult<List<PersonDto>>> GetAll()
    {
        var people = await _db.People
            .OrderBy(p => p.Name)
            .Select(p => new PersonDto(p.Id, p.Name, p.Age, p.IsMinor))
            .ToListAsync();

        return Ok(people);
    }

    /// <summary>POST /api/people — cria uma nova pessoa.</summary>
    [HttpPost]
    public async Task<ActionResult<PersonDto>> Create(CreatePersonDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            return BadRequest(new ErrorResponse("O nome é obrigatório."));

        if (dto.Age < 0 || dto.Age > 150)
            return BadRequest(new ErrorResponse("Idade inválida."));

        var person = new Person
        {
            Name = dto.Name.Trim(),
            Age = dto.Age
        };

        _db.People.Add(person);
        await _db.SaveChangesAsync();

        var result = new PersonDto(person.Id, person.Name, person.Age, person.IsMinor);
        return CreatedAtAction(nameof(GetAll), new { id = person.Id }, result);
    }

    /// <summary>
    /// DELETE /api/people/{id} — remove uma pessoa.
    /// Regra de negócio: ao deletar a pessoa, todas as suas transações
    /// também são apagadas. Isso é garantido pelo cascade delete configurado
    /// no AppDbContext, então basta remover a pessoa.
    /// </summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var person = await _db.People.FindAsync(id);
        if (person is null)
            return NotFound(new ErrorResponse("Pessoa não encontrada."));

        _db.People.Remove(person);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
