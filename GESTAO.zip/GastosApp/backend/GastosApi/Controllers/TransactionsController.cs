using GastosApi.Data;
using GastosApi.DTOs;
using GastosApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GastosApi.Controllers;

/// <summary>
/// Endpoints do cadastro de transações: criação e listagem
/// (a especificação diz explicitamente que edição/deleção não são necessárias).
/// </summary>
[ApiController]
[Route("api/transactions")]
public class TransactionsController : ControllerBase
{
    private readonly AppDbContext _db;

    public TransactionsController(AppDbContext db)
    {
        _db = db;
    }

    /// <summary>GET /api/transactions — lista todas as transações cadastradas.</summary>
    [HttpGet]
    public async Task<ActionResult<List<TransactionDto>>> GetAll()
    {
        var transactions = await _db.Transactions
            .OrderByDescending(t => t.Id)
            .Select(t => new TransactionDto(t.Id, t.Description, t.Value, t.Type, t.PersonId))
            .ToListAsync();

        return Ok(transactions);
    }

    /// <summary>
    /// POST /api/transactions — cria uma nova transação.
    /// Regras de negócio aplicadas aqui (na ordem em que fazem sentido):
    ///  1. A pessoa informada precisa existir no cadastro.
    ///  2. Se a pessoa for menor de idade (menos de 18 anos), somente
    ///     transações do tipo Despesa podem ser cadastradas para ela.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<TransactionDto>> Create(CreateTransactionDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Description))
            return BadRequest(new ErrorResponse("A descrição é obrigatória."));

        if (dto.Value <= 0)
            return BadRequest(new ErrorResponse("O valor deve ser maior que zero."));

        // Regra 1: a pessoa referenciada precisa existir no cadastro de pessoas.
        var person = await _db.People.FindAsync(dto.PersonId);
        if (person is null)
            return BadRequest(new ErrorResponse("Pessoa informada não existe no cadastro."));

        // Regra 2: menor de idade só pode ter despesas cadastradas.
        if (person.IsMinor && dto.Type == TransactionType.Receita)
        {
            return BadRequest(new ErrorResponse(
                "Pessoa menor de idade (menos de 18 anos) só pode ter despesas cadastradas, não receitas."));
        }

        var transaction = new Transaction
        {
            Description = dto.Description.Trim(),
            Value = dto.Value,
            Type = dto.Type,
            PersonId = dto.PersonId
        };

        _db.Transactions.Add(transaction);
        await _db.SaveChangesAsync();

        var result = new TransactionDto(transaction.Id, transaction.Description, transaction.Value, transaction.Type, transaction.PersonId);
        return CreatedAtAction(nameof(GetAll), new { id = transaction.Id }, result);
    }
}
