using GastosApi.Data;
using GastosApi.DTOs;
using GastosApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GastosApi.Controllers;

/// <summary>
/// Endpoint da "Consulta de totais": lista todas as pessoas cadastradas com
/// o total de receitas, total de despesas e saldo (receita - despesa) de
/// cada uma, além do total geral (soma de todas as pessoas) ao final.
/// </summary>
[ApiController]
[Route("api/totals")]
public class TotalsController : ControllerBase
{
    private readonly AppDbContext _db;

    public TotalsController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<ActionResult<TotalsReportDto>> Get()
    {
        // Carregamos cada pessoa junto com suas transações para calcular os
        // totais em memória. Para o volume de dados de um sistema doméstico
        // de controle de gastos, isso é simples e suficiente; em uma base
        // muito maior, o cálculo poderia ser feito via GroupBy no banco.
        var people = await _db.People
            .Include(p => p.Transactions)
            .OrderBy(p => p.Name)
            .ToListAsync();

        var rows = new List<PersonTotalDto>();

        foreach (var person in people)
        {
            var totalIncome = person.Transactions
                .Where(t => t.Type == TransactionType.Receita)
                .Sum(t => t.Value);

            var totalExpense = person.Transactions
                .Where(t => t.Type == TransactionType.Despesa)
                .Sum(t => t.Value);

            var balance = totalIncome - totalExpense;

            rows.Add(new PersonTotalDto(person.Id, person.Name, totalIncome, totalExpense, balance));
        }

        var report = new TotalsReportDto(
            People: rows,
            GrandTotalIncome: rows.Sum(r => r.TotalIncome),
            GrandTotalExpense: rows.Sum(r => r.TotalExpense),
            GrandTotalBalance: rows.Sum(r => r.Balance)
        );

        return Ok(report);
    }
}
