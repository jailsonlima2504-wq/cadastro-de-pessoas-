using GastosApi.Models;

namespace GastosApi.DTOs;

// ----- Pessoa -----

/// <summary>Dados recebidos para criar uma pessoa.</summary>
public record CreatePersonDto(string Name, int Age);

/// <summary>Dados devolvidos para o cliente representando uma pessoa.</summary>
public record PersonDto(int Id, string Name, int Age, bool IsMinor);

// ----- Transação -----

/// <summary>Dados recebidos para criar uma transação.</summary>
public record CreateTransactionDto(string Description, decimal Value, TransactionType Type, int PersonId);

/// <summary>Dados devolvidos para o cliente representando uma transação.</summary>
public record TransactionDto(int Id, string Description, decimal Value, TransactionType Type, int PersonId);

// ----- Consulta de totais -----

/// <summary>Totais (receita, despesa, saldo) de uma única pessoa.</summary>
public record PersonTotalDto(int PersonId, string Name, decimal TotalIncome, decimal TotalExpense, decimal Balance);

/// <summary>Resposta completa da consulta de totais: uma linha por pessoa + total geral.</summary>
public record TotalsReportDto(List<PersonTotalDto> People, decimal GrandTotalIncome, decimal GrandTotalExpense, decimal GrandTotalBalance);

/// <summary>Formato padrão de erro devolvido pela API.</summary>
public record ErrorResponse(string Message);
