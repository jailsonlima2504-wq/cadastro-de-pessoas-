using GastosApi.Models;
using Microsoft.EntityFrameworkCore;

namespace GastosApi.Data;

/// <summary>
/// Contexto do Entity Framework Core. Usamos SQLite com um arquivo físico
/// (gastos.db) para garantir que os dados persistam mesmo depois de fechar
/// a aplicação, conforme exigido na especificação.
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Person> People => Set<Person>();
    public DbSet<Transaction> Transactions => Set<Transaction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Person>()
            .HasIndex(p => p.Name); // apenas para agilizar buscas, não é unique (nome não precisa ser único)

        modelBuilder.Entity<Transaction>()
            .HasOne(t => t.Person)
            .WithMany(p => p.Transactions)
            .HasForeignKey(t => t.PersonId)
            // Regra da especificação: ao deletar uma pessoa, todas as suas
            // transações devem ser apagadas junto -> cascade delete.
            .OnDelete(DeleteBehavior.Cascade);
    }
}
