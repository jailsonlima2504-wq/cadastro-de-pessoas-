using System.ComponentModel.DataAnnotations;

namespace GastosApi.Models;

/// <summary>
/// Representa uma pessoa cadastrada no sistema de controle de gastos.
/// O Id é gerado automaticamente pelo banco (identity), conforme exigido
/// na especificação ("Identificador deve ser único e gerado automaticamente").
/// </summary>
public class Person
{
    public int Id { get; set; }

    [Required]
    [MaxLength(150)]
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Idade da pessoa. É usada para aplicar a regra de negócio de que
    /// menores de 18 anos só podem ter despesas cadastradas (nunca receitas).
    /// </summary>
    [Range(0, 150)]
    public int Age { get; set; }

    /// <summary>
    /// Navegação para as transações da pessoa. Configurado no DbContext com
    /// delete cascade: ao excluir a pessoa, todas as suas transações
    /// são excluídas junto (regra explícita da especificação).
    /// </summary>
    public List<Transaction> Transactions { get; set; } = new();

    /// <summary>Regra de negócio central: pessoa é menor de idade (< 18 anos).</summary>
    public bool IsMinor => Age < 18;
}
