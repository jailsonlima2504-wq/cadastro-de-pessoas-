namespace GastosApi.Models;

/// <summary>
/// Tipo de uma transação financeira.
/// Usamos um enum (em vez de uma string livre) para garantir, em tempo de
/// compilação, que só existam os dois valores previstos pela especificação:
/// Despesa ou Receita.
/// </summary>
public enum TransactionType
{
    Despesa = 0,
    Receita = 1
}
