using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GastosApi.Models;

/// <summary>
/// Representa uma transação financeira (receita ou despesa) associada a uma
/// pessoa. O Id é gerado automaticamente (identity), como pedido na
/// especificação.
/// </summary>
public class Transaction
{
    public int Id { get; set; }

    [Required]
    [MaxLength(200)]
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Valor da transação. Sempre armazenado como número positivo; o sinal
    /// (soma ou subtração no saldo) é definido pelo campo Type, não pelo
    /// valor em si. Isso evita ambiguidade (ex: usuário digitar valor negativo).
    /// </summary>
    [Range(0.01, double.MaxValue, ErrorMessage = "O valor deve ser maior que zero.")]
    [Column(TypeName = "decimal(18,2)")]
    public decimal Value { get; set; }

    public TransactionType Type { get; set; }

    /// <summary>Chave estrangeira para a pessoa dona da transação.</summary>
    public int PersonId { get; set; }

    /// <summary>Propriedade de navegação (não obrigatória no payload de entrada).</summary>
    public Person? Person { get; set; }
}
