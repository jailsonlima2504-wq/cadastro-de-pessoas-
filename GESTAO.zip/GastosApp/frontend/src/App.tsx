import { useEffect, useState } from "react";
import { api } from "./api";
import { Person, TotalsReport, TransactionType } from "./types";
import { PersonForm } from "./components/PersonForm";
import { PeopleList } from "./components/PeopleList";
import { TransactionForm } from "./components/TransactionForm";
import { TotalsView } from "./components/TotalsView";

/**
 * Componente raiz. Orquestra o carregamento de dados da API e repassa
 * callbacks para os formulários/listas. Todo o estado "de verdade" vive
 * no back-end (persistido em SQLite); aqui mantemos apenas uma cópia em
 * memória para renderizar a tela, recarregada após cada operação.
 */
export default function App() {
  const [people, setPeople] = useState<Person[]>([]);
  const [totals, setTotals] = useState<TotalsReport | null>(null);
  const [globalError, setGlobalError] = useState<string | null>(null);

  async function reloadAll() {
    try {
      const [peopleData, totalsData] = await Promise.all([
        api.getPeople(),
        api.getTotals()
      ]);
      setPeople(peopleData);
      setTotals(totalsData);
      setGlobalError(null);
    } catch (err) {
      setGlobalError(
        "Não foi possível conectar à API. Verifique se o back-end (.NET) está rodando em http://localhost:5236."
      );
    }
  }

  useEffect(() => {
    reloadAll();
  }, []);

  async function handleCreatePerson(name: string, age: number) {
    await api.createPerson(name, age);
    await reloadAll();
  }

  async function handleDeletePerson(id: number) {
    await api.deletePerson(id);
    await reloadAll();
  }

  async function handleCreateTransaction(
    description: string,
    value: number,
    type: TransactionType,
    personId: number
  ) {
    await api.createTransaction(description, value, type, personId);
    await reloadAll();
  }

  return (
    <div className="container">
      <h1>Controle de Gastos Residenciais</h1>

      {globalError && <p className="error">{globalError}</p>}

      <section>
        <h2>Pessoas</h2>
        <PersonForm onCreate={handleCreatePerson} />
        <PeopleList people={people} onDelete={handleDeletePerson} />
      </section>

      <section>
        <h2>Transações</h2>
        <TransactionForm people={people} onCreate={handleCreateTransaction} />
      </section>

      <section>
        <h2>Consulta de totais</h2>
        <TotalsView report={totals} />
      </section>
    </div>
  );
}
