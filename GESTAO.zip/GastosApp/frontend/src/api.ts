import { Person, Transaction, TransactionType, TotalsReport } from "./types";

// URL base da API .NET. Ajuste aqui caso o back-end rode em outra porta.
const API_BASE = "http://localhost:5236/api";

/// Lança um erro legível a partir da resposta da API (que devolve
/// { message: string } em caso de erro de validação/regra de negócio).
async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let message = `Erro na requisição (HTTP ${res.status})`;
    try {
      const body = await res.json();
      if (body?.message) message = body.message;
    } catch {
      // resposta sem corpo JSON, mantém mensagem padrão
    }
    throw new Error(message);
  }
  // 204 No Content não tem corpo para parsear
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  // ---- Pessoas ----
  async getPeople(): Promise<Person[]> {
    const res = await fetch(`${API_BASE}/people`);
    return handleResponse<Person[]>(res);
  },

  async createPerson(name: string, age: number): Promise<Person> {
    const res = await fetch(`${API_BASE}/people`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, age })
    });
    return handleResponse<Person>(res);
  },

  async deletePerson(id: number): Promise<void> {
    const res = await fetch(`${API_BASE}/people/${id}`, { method: "DELETE" });
    return handleResponse<void>(res);
  },

  // ---- Transações ----
  async getTransactions(): Promise<Transaction[]> {
    const res = await fetch(`${API_BASE}/transactions`);
    return handleResponse<Transaction[]>(res);
  },

  async createTransaction(
    description: string,
    value: number,
    type: TransactionType,
    personId: number
  ): Promise<Transaction> {
    const res = await fetch(`${API_BASE}/transactions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ description, value, type, personId })
    });
    return handleResponse<Transaction>(res);
  },

  // ---- Totais ----
  async getTotals(): Promise<TotalsReport> {
    const res = await fetch(`${API_BASE}/totals`);
    return handleResponse<TotalsReport>(res);
  }
};
