// Tipos espelhando os DTOs do back-end (GastosApi.DTOs).

export type TransactionType = "Despesa" | "Receita";

export interface Person {
  id: number;
  name: string;
  age: number;
  isMinor: boolean;
}

export interface Transaction {
  id: number;
  description: string;
  value: number;
  type: TransactionType;
  personId: number;
}

export interface PersonTotal {
  personId: number;
  name: string;
  totalIncome: number;
  totalExpense: number;
  balance: number;
}

export interface TotalsReport {
  people: PersonTotal[];
  grandTotalIncome: number;
  grandTotalExpense: number;
  grandTotalBalance: number;
}
