import { Person } from "../types";

interface Props {
  people: Person[];
  onDelete: (id: number) => Promise<void>;
}

/**
 * Lista simples de pessoas cadastradas, com botão de exclusão.
 * Exibe um selo "menor de idade" para deixar clara a regra de negócio
 * que restringe transações de receita para esse grupo.
 */
export function PeopleList({ people, onDelete }: Props) {
  if (people.length === 0) {
    return <p className="muted">Nenhuma pessoa cadastrada ainda.</p>;
  }

  return (
    <ul className="list">
      {people.map((p) => (
        <li key={p.id} className="list-item">
          <span>
            <strong>{p.name}</strong> — {p.age} anos
            {p.isMinor && <span className="badge">menor de idade</span>}
          </span>
          <button
            className="danger"
            onClick={() => {
              if (window.confirm(`Excluir ${p.name}? Todas as transações dessa pessoa também serão apagadas.`)) {
                onDelete(p.id);
              }
            }}
          >
            Excluir
          </button>
        </li>
      ))}
    </ul>
  );
}
