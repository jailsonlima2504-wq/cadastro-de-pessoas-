import { useState } from "react";

interface Props {
  onCreate: (name: string, age: number) => Promise<void>;
}

/**
 * Formulário de criação de pessoa. Mantém apenas estado local dos campos;
 * quem efetivamente chama a API é o componente pai (App), via onCreate.
 */
export function PersonForm({ onCreate }: Props) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const ageNumber = Number(age);
    if (!name.trim()) {
      setError("Informe o nome.");
      return;
    }
    if (!Number.isInteger(ageNumber) || ageNumber < 0) {
      setError("Informe uma idade válida.");
      return;
    }

    setLoading(true);
    try {
      await onCreate(name.trim(), ageNumber);
      setName("");
      setAge("");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h3>Nova pessoa</h3>
      <div className="field-row">
        <input
          placeholder="Nome"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          placeholder="Idade"
          type="number"
          min={0}
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Salvando..." : "Adicionar"}
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </form>
  );
}
