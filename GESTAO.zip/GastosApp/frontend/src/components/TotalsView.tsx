import { TotalsReport } from "../types";

interface Props {
  report: TotalsReport | null;
}

function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

/**
 * Consulta de totais: uma linha por pessoa (receita, despesa, saldo) e,
 * ao final, o total geral somando todas as pessoas — exatamente como
 * pedido na especificação.
 */
export function TotalsView({ report }: Props) {
  if (!report) return <p className="muted">Carregando totais...</p>;

  if (report.people.length === 0) {
    return <p className="muted">Nenhuma pessoa cadastrada ainda.</p>;
  }

  return (
    <table className="totals-table">
      <thead>
        <tr>
          <th>Pessoa</th>
          <th>Receitas</th>
          <th>Despesas</th>
          <th>Saldo</th>
        </tr>
      </thead>
      <tbody>
        {report.people.map((p) => (
          <tr key={p.personId}>
            <td>{p.name}</td>
            <td>{formatCurrency(p.totalIncome)}</td>
            <td>{formatCurrency(p.totalExpense)}</td>
            <td className={p.balance < 0 ? "negative" : "positive"}>
              {formatCurrency(p.balance)}
            </td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td>
            <strong>Total geral</strong>
          </td>
          <td>
            <strong>{formatCurrency(report.grandTotalIncome)}</strong>
          </td>
          <td>
            <strong>{formatCurrency(report.grandTotalExpense)}</strong>
          </td>
          <td className={report.grandTotalBalance < 0 ? "negative" : "positive"}>
            <strong>{formatCurrency(report.grandTotalBalance)}</strong>
          </td>
        </tr>
      </tfoot>
    </table>
  );
}
