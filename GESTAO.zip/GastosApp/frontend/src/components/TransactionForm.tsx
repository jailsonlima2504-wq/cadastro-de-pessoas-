import { useState } from "react";
import { Person, TransactionType } from "../types";

interface Props {
  people: Person[];
  onCreate: (description: string, value: number, type: TransactionType, personId: number) => Promise<void>;
}

/**
 * Formulário de criação de transação.
 * Se a pessoa selecionada for menor de idade, a opção "Receita" é
 * desabilitada no próprio front-end (feedback imediato ao usuário),
 * mas a regra de negócio real é validada no back-end de qualquer forma.
 */
export function TransactionForm({ people, onCreate }: Props) {
  const [description, setDescription] = useState("");
  const [value, setValue] = useState("");
  const [type, setType] = useState<TransactionType>("Despesa");
  const [personId, setPersonId] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const selectedPerson = people.find((p) => p.id === Number(personId));
  const receitaDisabled = selectedPerson?.isMinor ?? false;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const valueNumber = Number(value);
    if (!description.trim()) {
      setError("Informe a descrição.");
      return;
    }
    if (!valueNumber || valueNumber <= 0) {
      setError("Informe um valor maior que zero.");
      return;
    }
    if (!personId) {
      setError("Selecione a pessoa.");
      return;
    }

    setLoading(true);
    try {
      await onCreate(description.trim(), valueNumber, type, Number(personId));
      setDescription("");
      setValue("");
      setType("Despesa");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h3>Nova transação</h3>
      <div className="field-row">
        <select value={personId} onChange={(e) => setPersonId(e.target.value)}>
          <option value="">Selecione a pessoa</option>
          {people.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
              {p.isMinor ? " (menor de idade)" : ""}
            </option>
          ))}
        </select>
        <input
          placeholder="Descrição"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          placeholder="Valor"
          type="number"
          min={0.01}
          step={0.01}
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
        <select
          value={type}
          onChange={(e) => setType(e.target.value as TransactionType)}
        >
          <option value="Despesa">Despesa</option>
          <option value="Receita" disabled={receitaDisabled}>
            Receita
          </option>
        </select>
        <button type="submit" disabled={loading}>
          {loading ? "Salvando..." : "Adicionar"}
        </button>
      </div>
      {receitaDisabled && (
        <p className="hint">Pessoa menor de idade: apenas despesas podem ser cadastradas.</p>
      )}
      {error && <p className="error">{error}</p>}
    </form>
  );
}
